const body = document.body;
const menuToggle = document.querySelector(".menu-toggle");
const nav = document.querySelector("#site-nav");
const navLinks = document.querySelectorAll(".site-nav a");
const form = document.querySelector(".contact-form");
const statusMessage = document.querySelector(".form-status");

function setMenu(open) {
  body.classList.toggle("nav-open", open);
  menuToggle?.setAttribute("aria-expanded", String(open));
}

menuToggle?.addEventListener("click", () => {
  setMenu(!body.classList.contains("nav-open"));
});

navLinks.forEach((link) => {
  link.addEventListener("click", () => setMenu(false));
});

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") {
    setMenu(false);
  }
});

form?.addEventListener("submit", (event) => {
  if (!form.dataset.emailTo) return;

  event.preventDefault();
  const formData = new FormData(form);
  const name = String(formData.get("name") || "").trim();
  const email = String(formData.get("email") || "").trim();
  const message = String(formData.get("message") || "").trim();
  const recipient = form.dataset.emailTo || "jeffreyhaslitt@mccs.school";
  const subject = encodeURIComponent(`The Island message from ${name || "a student or family"}`);
  const body = encodeURIComponent([
    `Name: ${name}`,
    `Email: ${email}`,
    "",
    message
  ].join("\n"));

  window.location.href = `mailto:${recipient}?subject=${subject}&body=${body}`;
  statusMessage.textContent = "Your email app should open with the message ready to send.";
  form.reset();
});

document.addEventListener("click", (event) => {
  if (!body.classList.contains("nav-open")) return;
  if (nav?.contains(event.target) || menuToggle?.contains(event.target)) return;
  setMenu(false);
});
