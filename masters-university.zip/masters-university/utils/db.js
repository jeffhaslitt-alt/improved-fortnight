// utils/db.js — JSON-based data storage utilities

const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const DATA_DIR = path.join(__dirname, '../data');

/**
 * Read a JSON data file
 * @param {string} filename - e.g. 'students', 'programs', 'credentials'
 * @returns {object} parsed JSON content
 */
function readData(filename) {
  const filePath = path.join(DATA_DIR, `${filename}.json`);
  try {
    const raw = fs.readFileSync(filePath, 'utf8');
    return JSON.parse(raw);
  } catch (err) {
    throw new Error(`Failed to read data file "${filename}.json": ${err.message}`);
  }
}

/**
 * Write data to a JSON file
 * @param {string} filename - e.g. 'students', 'credentials'
 * @param {object} data - data to write
 */
function writeData(filename, data) {
  const filePath = path.join(DATA_DIR, `${filename}.json`);
  try {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf8');
  } catch (err) {
    throw new Error(`Failed to write data file "${filename}.json": ${err.message}`);
  }
}

/**
 * Generate a student ID
 * Format: STU-YYYYMMDD-XXXX
 */
function generateStudentId() {
  const date = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  const suffix = Math.random().toString(36).toUpperCase().slice(2, 6);
  return `STU-${date}-${suffix}`;
}

/**
 * Generate a credential ID
 * Format: CRED-PROG001-YYYYMMDD-XXXX
 */
function generateCredentialId(programCode) {
  const date = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  const suffix = uuidv4().replace(/-/g, '').slice(0, 8).toUpperCase();
  return `CRED-${programCode}-${date}-${suffix}`;
}

/**
 * Find a student by ID
 */
function findStudentById(studentId) {
  const { students } = readData('students');
  return students.find(s => s.id === studentId) || null;
}

/**
 * Save or update a student record
 */
function upsertStudent(updatedStudent) {
  const data = readData('students');
  const idx = data.students.findIndex(s => s.id === updatedStudent.id);
  if (idx === -1) {
    data.students.push(updatedStudent);
  } else {
    data.students[idx] = updatedStudent;
  }
  writeData('students', data);
  return updatedStudent;
}

/**
 * Find a credential by ID
 */
function findCredentialById(credentialId) {
  const { credentials } = readData('credentials');
  return credentials.find(c => c.id === credentialId) || null;
}

/**
 * Save a new credential
 */
function saveCredential(credential) {
  const data = readData('credentials');
  data.credentials.push(credential);
  writeData('credentials', data);
  return credential;
}

module.exports = {
  readData,
  writeData,
  generateStudentId,
  generateCredentialId,
  findStudentById,
  upsertStudent,
  findCredentialById,
  saveCredential,
};
