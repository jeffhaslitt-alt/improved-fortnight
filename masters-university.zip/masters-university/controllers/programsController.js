// controllers/programsController.js

const { readData } = require('../utils/db');

/**
 * GET /api/programs
 * Return all programs
 */
function getAllPrograms(req, res) {
  try {
    const { programs } = readData('programs');
    const summary = programs.map(p => ({
      id: p.id,
      title: p.title,
      code: p.code,
      level: p.level,
      description: p.description,
      credits: p.credits,
      estimatedWeeks: p.estimatedWeeks,
      moduleCount: p.modules.length,
      modules: p.modules.map(m => ({
        id: m.id,
        sequence: m.sequence,
        title: m.title,
        code: m.code,
        credits: m.credits,
        description: m.description,
        learningOutcomes: m.learningOutcomes,
      })),
    }));
    res.json({ success: true, count: programs.length, programs: summary });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
}

/**
 * GET /api/programs/:id
 * Return a single program
 */
function getProgram(req, res) {
  try {
    const { programs } = readData('programs');
    const program = programs.find(p => p.id === req.params.id);
    if (!program) {
      return res.status(404).json({ success: false, error: 'Program not found.' });
    }
    res.json({ success: true, program });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
}

module.exports = { getAllPrograms, getProgram };
