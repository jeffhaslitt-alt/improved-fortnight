// controllers/agentController.js
// Routes student messages to the AI Advisor engine

const { findStudentById } = require('../utils/db');
const { processMessage } = require('../utils/advisor');

/**
 * Detect intent from message text
 */
function detectIntent(text) {
  const t = text.trim().toLowerCase();
  if (t === 'start' || t === 'begin' || t === 'go') return 'start';
  if (t === 'next module' || t === 'next' || t === 'advance' || t === 'continue') return 'next_module';
  if (t === 'status' || t === 'progress' || t === 'where am i') return 'status';
  if (t === 'help' || t === '?' || t === 'commands') return 'help';
  // If long text, treat as reflection submission
  if (text.trim().split(/\s+/).length > 30) return 'submit_reflection';
  return 'unknown';
}

/**
 * POST /api/agent/message
 * Body: { studentId, message }
 */
async function handleMessage(req, res) {
  const { studentId, message } = req.body;

  if (!studentId || !message) {
    return res.status(400).json({
      success: false,
      error: 'studentId and message are required.',
    });
  }

  const student = findStudentById(studentId);
  if (!student) {
    return res.status(404).json({
      success: false,
      error: `Student "${studentId}" not found. Please enroll first.`,
    });
  }

  const intent = detectIntent(message);

  try {
    const result = await processMessage(studentId, intent, message);
    res.json({
      success: true,
      studentId,
      intent,
      reply: result.reply,
      action: result.action || null,
      data: result.data || {},
      timestamp: new Date().toISOString(),
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
}

module.exports = { handleMessage };
