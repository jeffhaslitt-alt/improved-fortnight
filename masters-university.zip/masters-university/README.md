# The Master's University of Professional Studies
## Complete System — Setup & Reference Guide

---

## OVERVIEW

A fully functional micro-university prototype with:
- AI Advisor system (reflection evaluation + degree conferral)
- Node.js + Express backend with JSON data storage
- 4-module graduate certificate program
- Landing page, student portal, certificate, and credential verification

---

## FILE STRUCTURE

```
masters-university/
│
├── server.js                    # Express server entry point
├── package.json
├── CHARTER.md                   # University charter & identity
│
├── controllers/
│   ├── studentsController.js    # Enrollment, lookup
│   ├── programsController.js    # Program data
│   ├── agentController.js       # AI Advisor message routing
│   └── credentialsController.js # Verification
│
├── utils/
│   ├── db.js                    # JSON read/write + ID generators
│   └── advisor.js               # Evaluation, progress, degree engines
│
├── data/
│   ├── programs.json            # Program + module definitions
│   ├── students.json            # Student records (persisted)
│   └── credentials.json         # Issued credentials (persisted)
│
└── public/
    ├── index.html               # Landing page + enrollment + portal
    ├── verify.html              # Credential verification page
    └── certificate.html         # Printable degree certificate
```

---

## QUICK START

### 1. Install dependencies
```bash
cd masters-university
npm install
```

### 2. Start the server
```bash
npm start
# or for development with auto-reload:
npm run dev
```

### 3. Open the application
Navigate to: **http://localhost:3000**

---

## API REFERENCE

### Health Check
```
GET /api
```

### Students
```
GET  /api/students          # All students
POST /api/students          # Enroll a student
     Body: { name, email, programId: "prog-001" }
GET  /api/students/:id      # Student record + progress
```

### Programs
```
GET /api/programs           # All programs
GET /api/programs/:id       # Single program
```

### AI Advisor
```
POST /api/agent/message
     Body: { studentId, message }

Recognized intents (message text):
  "start"           → Begin or resume current module
  "next module"     → Advance to next module
  "status"          → View progress across all modules
  "help"            → Show available commands
  [long text]       → Automatically treated as reflection submission
```

### Credentials
```
GET /api/credentials                 # All credentials
GET /api/credentials/verify/:id      # Verify by credential ID
GET /verify/:id                      # Redirects to verify.html
```

---

## STUDENT JOURNEY (Full Flow)

```
1. Student visits index.html
2. Student enrolls (name + email) → receives Student ID
3. Student pastes Student ID into portal
4. Student types "start" → Module I brief appears
5. Student submits reflection (200+ words) → AI evaluates
6. If score ≥ 7/10: module complete → next module unlocked
7. If score < 7/10: feedback given → resubmit
8. After all 4 modules: degree conferred automatically
9. Credential issued with unique ID + verification URL
10. Certificate viewable at /certificate.html?[params]
11. Anyone can verify at /verify/:id or /verify.html
```

---

## AI ADVISOR EVALUATION ENGINE

Reflections are scored 0–10 across 5 dimensions (2 pts each):

| Dimension | What It Checks |
|---|---|
| Word count | Meets minimum length requirement |
| Personal voice | First-person introspective language |
| Specificity | Concrete examples and grounded details |
| Depth | Evidence of genuine wrestling with ideas |
| Integration | Connecting insight to action or other domains |

**Passing scores by module:**
- Modules 1–3: 7/10 minimum
- Module 4 (Capstone): 8/10 minimum

---

## PROGRAM: FOUNDATIONS OF IDENTITY & SYSTEMS

| Module | Code | Credits | Min Words | Min Score |
|---|---|---|---|---|
| I. Identity Foundations | FIS-101 | 3 | 200 | 7 |
| II. Systems Thinking | FIS-201 | 3 | 200 | 7 |
| III. Embodied Practice | FIS-301 | 3 | 200 | 7 |
| IV. Personal Operating System | FIS-401 | 3 | 300 | 8 |

**Total: 12 credits — Graduate Certificate**

---

## CREDENTIAL FORMAT

```
Credential ID:    CRED-FIS001-YYYYMMDD-XXXXXXXX
Student Name:     [Full name]
Program:          Foundations of Identity & Systems
Issued Date:      YYYY-MM-DD
Issued By:        The Master's University of Professional Studies
Verification URL: http://localhost:3000/verify/[CRED-ID]
Status:           valid | revoked
```

---

## SAMPLE API CALLS

### Enroll a student
```bash
curl -X POST http://localhost:3000/api/students \
  -H "Content-Type: application/json" \
  -d '{"name":"Jane Smith","email":"jane@example.com","programId":"prog-001"}'
```

### Send a message to the Advisor
```bash
curl -X POST http://localhost:3000/api/agent/message \
  -H "Content-Type: application/json" \
  -d '{"studentId":"STU-20260511-XXXX","message":"start"}'
```

### Verify a credential
```bash
curl http://localhost:3000/api/credentials/verify/CRED-FIS001-20260511-ABCD1234
```

---

## FOUNDING VALUES

| Latin | English |
|---|---|
| Veritas | Truth |
| Sapientia | Wisdom |
| Disciplina | Discipline |
| Integritas | Integrity |

**Motto:** *Veritas et Sapientia*  
**Established:** 2026

---

*The Master's University of Professional Studies*  
*Where mastery is a way of being, not a box to check.*
