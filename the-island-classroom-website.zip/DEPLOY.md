# Deploy The Island Classroom Website

This is a static website. It can be hosted by any service that supports HTML, CSS, JavaScript, and image files.

## Easiest Option: Netlify Drop

1. Go to https://app.netlify.com/drop
2. Drag the deployment ZIP file into the page.
3. Netlify will publish the site and give you a public URL.
4. Open the public URL and test the contact form.
5. The first contact form submission should send a confirmation email to `jeffreyhaslitt@mccs.school`.
6. Confirm that email once, then future form submissions should be delivered.

## Files To Upload

Upload the full contents of this folder:

- `index.html`
- `files.html`
- `teacher.html`
- `styles.css`
- `script.js`
- `files.js`
- `assets/classroom-hero.png`

## Contact Form

The contact form posts to FormSubmit:

`https://formsubmit.co/jeffreyhaslitt@mccs.school`

It will not fully work as a real email form until the site is hosted and the first FormSubmit confirmation email is approved.

## Class Files Page

The Class Files library stores uploaded files in the visitor's current browser using IndexedDB. Those files are local to that browser and device. They are not shared between students or uploaded to the website host.
