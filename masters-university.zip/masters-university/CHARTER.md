# THE MASTER'S UNIVERSITY OF PROFESSIONAL STUDIES
## Founding Charter & Identity Document
### Established 2026

---

## I. MISSION

The Master's University of Professional Studies exists to cultivate whole persons — 
individuals who think with clarity, act with integrity, and lead with wisdom. We 
pursue mastery not as a credential but as a way of being: a lifelong commitment to 
truth, growth, and service.

We are a mastery-based, AI-guided institution designed for the professional era — 
where knowledge is abundant but wisdom is rare, where information is instant but 
understanding is hard-won.

---

## II. FOUNDING VALUES

**VERITAS** — Truth  
We pursue truth rigorously, even when inconvenient. Intellectual honesty is not 
optional. We do not mistake confidence for correctness, nor comfort for wisdom.

**SAPIENTIA** — Wisdom  
Knowledge without wisdom is machinery without purpose. We cultivate the capacity 
to discern — to know not just what is true, but what matters and why.

**DISCIPLINA** — Discipline  
Growth is earned. Mastery requires sustained effort, structured practice, and the 
willingness to be a beginner. We honor the process, not just the outcome.

**INTEGRITAS** — Integrity  
Character is the foundation of all achievement. We hold ourselves to the standard 
we claim to teach. What we profess, we practice.

---

## III. GOVERNANCE STRUCTURE

### Academic Council
The Academic Council is the supreme academic authority of the University. It 
oversees curriculum, standards, and credentialing. The Council meets in standing 
session and may be convened in emergency by any two members.

**Composition:**
- Dean of Academic Affairs (Chair)
- Director of Curriculum
- Director of Student Experience
- Two Student Representatives (elected per cohort)

### Office of the Registrar
The Registrar maintains all official academic records, manages enrollment and 
completion data, issues credentials, and administers the verification system.

### AI Council
The AI Council governs the deployment, ethics, and ongoing calibration of AI 
systems within the university. It ensures that AI Advisor interactions meet 
pedagogical standards and do not compromise student autonomy or intellectual growth.

**Responsibilities:**
- Monthly audit of AI Advisor evaluation accuracy
- Review of reflection depth metrics
- Ethics oversight of AI-student interactions
- Curriculum alignment of AI guidance systems

### Founding Office
The Founding Office holds the institutional memory, mission stewardship, and 
long-term vision of the University. It reports to no operational body but is 
accountable to the founding charter.

---

## IV. ACADEMIC MODEL

### Mastery-Based Progression
Students advance by demonstrating competency, not by accumulating time. Each module 
has defined mastery criteria. Advancement requires meeting those criteria.

### AI-Guided Learning
Each student is assigned a persistent AI Advisor that accompanies them through their 
entire program. The Advisor evaluates reflections, tracks progress, provides 
challenge prompts, and confers credentials upon completion.

### Competency Progression Framework
1. **Awareness** — Student can articulate the concept
2. **Comprehension** — Student can explain it in their own words
3. **Application** — Student can apply it in context
4. **Integration** — Student can connect it to other knowledge
5. **Mastery** — Student can teach it, question it, and extend it

---

## V. STUDENT BILL OF RIGHTS

Every enrolled student of The Master's University of Professional Studies holds the 
following rights, which no faculty member, administrator, or AI system may abridge:

1. **The Right to Honest Evaluation** — Students have the right to receive honest, 
   calibrated feedback on their work, not flattery or empty validation.

2. **The Right to Explanation** — Students may request the reasoning behind any 
   evaluation, grade, or advancement decision.

3. **The Right to Re-attempt** — No single submission is final. Students may 
   resubmit any reflection or assessment.

4. **The Right to Advocate** — Students may appeal any academic decision to the 
   Academic Council.

5. **The Right to Privacy** — Student data is never sold, shared with third parties, 
   or used for purposes beyond the student's academic experience.

6. **The Right to Clarity** — Expectations, rubrics, and requirements will be made 
   explicit before any evaluation.

7. **The Right to Human Contact** — Every student has the right to connect with a 
   human staff member at any point in their academic journey.

---

## VI. CODE OF ACADEMIC INTEGRITY

### Principle
Academic integrity is the foundation of learning. A credential without honest effort 
is not a credential — it is a lie with a seal on it. We hold ourselves to what we claim.

### Prohibited Conduct
- **Falsification**: Misrepresenting one's identity, work, or credentials
- **Submission fraud**: Submitting work that is not genuinely one's own reflection
- **System manipulation**: Attempting to exploit AI Advisor systems for unearned advancement
- **Credential misrepresentation**: Claiming credentials not legitimately earned
- **Plagiarism**: Presenting others' ideas as one's own without attribution

### Process
1. Any suspected violation triggers a review by the Registrar
2. Student is notified and given opportunity to respond
3. Academic Council renders a decision within 14 days
4. Sanctions range from re-submission requirements to credential revocation

### Affirmation
By enrolling, each student affirms: *"I will engage honestly with every evaluation, 
reflection, and interaction. I understand that the only person I deceive by 
cheating is myself."*

---

## VII. CREDENTIALING PHILOSOPHY

### What a Credential Means
A credential from The Master's University is a statement of demonstrated competency — 
not of time served, tuition paid, or attendance logged. It attests that the holder 
has engaged in genuine mastery work and met defined standards.

### Verification System
Every credential issued carries a unique Credential ID and a public verification URL. 
Any employer, institution, or individual may verify the credential's authenticity, 
the program completed, and the date of conferral.

### Credential Integrity
Credentials are cryptographically signed at issuance. Tampering invalidates the 
verification check. The Registrar maintains a permanent record of all issued credentials.

---

*Ratified by the Founding Office*  
*The Master's University of Professional Studies*  
*Anno Domini 2026*
