// server.js — The Master's University of Professional Studies
// Node.js + Express backend

const express = require('express');
const cors = require('cors');
const path = require('path');

const { getAllStudents, enrollStudent, getStudent } = require('./controllers/studentsController');
const { getAllPrograms, getProgram } = require('./controllers/programsController');
const { handleMessage } = require('./controllers/agentController');
const { verifyCredential, getAllCredentials } = require('./controllers/credentialsController');

const app = express();
const PORT = process.env.PORT || 3000;

// ── Middleware ──
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ── Health check ──
app.get('/api', (req, res) => {
  res.json({
    university: "The Master's University of Professional Studies",
    status: 'operational',
    version: '1.0.0',
    established: 2026,
    motto: 'Veritas et Sapientia',
    endpoints: {
      students: '/api/students',
      programs: '/api/programs',
      agent: '/api/agent/message',
      verify: '/api/credentials/verify/:id',
    },
  });
});

// ── Student Routes ──
app.get('/api/students', getAllStudents);
app.post('/api/students', enrollStudent);
app.get('/api/students/:id', getStudent);

// ── Program Routes ──
app.get('/api/programs', getAllPrograms);
app.get('/api/programs/:id', getProgram);

// ── AI Advisor Route ──
app.post('/api/agent/message', handleMessage);

// ── Credential Routes ──
app.get('/api/credentials', getAllCredentials);
app.get('/api/credentials/verify/:id', verifyCredential);

// ── Credential Verification Page (redirect) ──
app.get('/verify/:id', (req, res) => {
  res.redirect(`/verify.html?id=${req.params.id}`);
});

// ── 404 ──
app.use((req, res) => {
  res.status(404).json({ error: 'Endpoint not found.' });
});

// ── Error handler ──
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Internal server error.' });
});

app.listen(PORT, () => {
  console.log(`\n╔══════════════════════════════════════════════════╗`);
  console.log(`║  The Master's University of Professional Studies  ║`);
  console.log(`║  Server running on http://localhost:${PORT}         ║`);
  console.log(`║  Veritas et Sapientia                             ║`);
  console.log(`╚══════════════════════════════════════════════════╝\n`);
});

module.exports = app;
