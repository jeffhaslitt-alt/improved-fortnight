// controllers/credentialsController.js

const { findCredentialById, readData } = require('../utils/db');

/**
 * GET /api/credentials/verify/:id
 * Verify a credential by ID — public endpoint
 */
function verifyCredential(req, res) {
  const { id } = req.params;

  try {
    const credential = findCredentialById(id);

    if (!credential) {
      return res.status(404).json({
        success: false,
        valid: false,
        error: `No credential found with ID "${id}". This credential may be invalid or does not exist in our records.`,
      });
    }

    if (credential.status === 'revoked') {
      return res.json({
        success: true,
        valid: false,
        credential: {
          id: credential.id,
          status: 'revoked',
          revokedAt: credential.revokedAt || null,
          revokedReason: credential.revokedReason || 'Academic integrity violation',
        },
      });
    }

    res.json({
      success: true,
      valid: true,
      message: 'This credential is authentic and has been verified by the Office of the Registrar.',
      credential: {
        id: credential.id,
        studentName: credential.studentName,
        programTitle: credential.programTitle,
        programCode: credential.programCode,
        issuedDate: credential.issuedDate,
        issuedBy: credential.issuedBy,
        seal: credential.seal,
        status: credential.status,
        verificationUrl: credential.verificationUrl,
      },
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
}

/**
 * GET /api/credentials
 * Return all credentials (admin use)
 */
function getAllCredentials(req, res) {
  try {
    const { credentials } = readData('credentials');
    res.json({ success: true, count: credentials.length, credentials });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
}

module.exports = { verifyCredential, getAllCredentials };
