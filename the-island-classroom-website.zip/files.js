const DB_NAME = "the-island-curriculum-library";
const DB_VERSION = 1;
const STORE_NAME = "files";

const uploadForm = document.querySelector("#file-upload-form");
const fileInput = document.querySelector("#curriculum-files");
const libraryStatus = document.querySelector(".library-status");
const fileList = document.querySelector("#file-list");
const emptyLibrary = document.querySelector("#empty-library");
const searchInput = document.querySelector("#library-search");
const subjectFilter = document.querySelector("#subject-filter");
const selectedFilesLabel = document.querySelector("[data-selected-files]");
const totalFiles = document.querySelector("[data-total-files]");
const totalSize = document.querySelector("[data-total-size]");
const newestFile = document.querySelector("[data-newest-file]");

let dbPromise;
let libraryFiles = [];

function openLibraryDb() {
  if (dbPromise) return dbPromise;

  dbPromise = new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.addEventListener("upgradeneeded", () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        const store = db.createObjectStore(STORE_NAME, { keyPath: "id" });
        store.createIndex("subject", "subject", { unique: false });
        store.createIndex("uploadedAt", "uploadedAt", { unique: false });
      }
    });

    request.addEventListener("success", () => resolve(request.result));
    request.addEventListener("error", () => reject(request.error));
  });

  return dbPromise;
}

async function runStore(mode, action) {
  const db = await openLibraryDb();

  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, mode);
    const store = transaction.objectStore(STORE_NAME);
    const result = action(store);

    transaction.addEventListener("complete", () => resolve(result?.result));
    transaction.addEventListener("error", () => reject(transaction.error));
  });
}

function formatBytes(bytes) {
  if (!bytes) return "0 KB";
  const units = ["B", "KB", "MB", "GB"];
  let size = bytes;
  let unitIndex = 0;

  while (size >= 1024 && unitIndex < units.length - 1) {
    size /= 1024;
    unitIndex += 1;
  }

  return `${size.toFixed(size >= 10 || unitIndex === 0 ? 0 : 1)} ${units[unitIndex]}`;
}

function formatDate(value) {
  return new Intl.DateTimeFormat("en", {
    month: "short",
    day: "numeric",
    year: "numeric"
  }).format(new Date(value));
}

function fileKind(type, name) {
  const extension = name.includes(".") ? name.split(".").pop().toUpperCase() : "FILE";
  if (type.includes("pdf")) return "PDF";
  if (type.includes("image")) return "Image";
  if (type.includes("presentation")) return "Slides";
  if (type.includes("spreadsheet") || ["XLS", "XLSX", "CSV"].includes(extension)) return "Sheet";
  if (type.includes("document") || ["DOC", "DOCX", "TXT"].includes(extension)) return "Doc";
  return extension.slice(0, 6);
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

async function readAllFiles() {
  const files = await runStore("readonly", (store) => store.getAll());
  libraryFiles = [...(files || [])].sort((a, b) => b.uploadedAt - a.uploadedAt);
  renderLibrary();
}

function updateStats(files) {
  const bytes = files.reduce((sum, file) => sum + file.size, 0);
  totalFiles.textContent = String(files.length);
  totalSize.textContent = formatBytes(bytes);
  newestFile.textContent = files[0] ? formatDate(files[0].uploadedAt) : "None yet";
}

function filteredFiles() {
  const query = searchInput.value.trim().toLowerCase();
  const subject = subjectFilter.value;

  return libraryFiles.filter((file) => {
    const matchesSubject = subject === "All" || file.subject === subject;
    const searchable = [file.name, file.subject, file.grade, file.tags, file.notes, file.kind]
      .join(" ")
      .toLowerCase();
    return matchesSubject && (!query || searchable.includes(query));
  });
}

function renderLibrary() {
  updateStats(libraryFiles);
  const files = filteredFiles();

  fileList.innerHTML = files
    .map((file) => {
      const tags = file.tags
        .split(",")
        .map((tag) => tag.trim())
        .filter(Boolean)
        .map((tag) => `<span>${escapeHtml(tag)}</span>`)
        .join("");

      return `
        <article class="file-card">
          <div class="file-type">${escapeHtml(file.kind)}</div>
          <div class="file-main">
            <div>
              <h3>${escapeHtml(file.name)}</h3>
              <p>${escapeHtml(file.subject)} | ${escapeHtml(file.grade || "All grades")} | ${formatBytes(file.size)}</p>
            </div>
            <p>${escapeHtml(file.notes || "No notes added.")}</p>
            <div class="tag-list">${tags || "<span>No tags</span>"}</div>
            <small>Uploaded ${formatDate(file.uploadedAt)}</small>
          </div>
          <div class="file-actions">
            <button class="button secondary dark" type="button" data-action="download" data-id="${file.id}">Download</button>
            <button class="button ghost" type="button" data-action="delete" data-id="${file.id}">Delete</button>
          </div>
        </article>
      `;
    })
    .join("");

  emptyLibrary.hidden = libraryFiles.length > 0;
  fileList.hidden = files.length === 0;

  if (libraryFiles.length > 0 && files.length === 0) {
    emptyLibrary.hidden = false;
    emptyLibrary.querySelector("strong").textContent = "No files match that search.";
    emptyLibrary.querySelector("p").textContent = "Try a different keyword or subject filter.";
  } else {
    emptyLibrary.querySelector("strong").textContent = "No files in the library yet.";
    emptyLibrary.querySelector("p").textContent = "Upload curriculum materials to build a searchable classroom collection.";
  }
}

async function saveUploads(event) {
  event.preventDefault();
  const selectedFiles = [...fileInput.files];

  if (selectedFiles.length === 0) {
    libraryStatus.textContent = "Choose at least one file to save.";
    return;
  }

  const formData = new FormData(uploadForm);
  const subject = String(formData.get("subject"));
  const grade = String(formData.get("grade") || "").trim();
  const tags = String(formData.get("tags") || "").trim();
  const notes = String(formData.get("notes") || "").trim();
  const uploadedAt = Date.now();

  await runStore("readwrite", (store) => {
    selectedFiles.forEach((file, index) => {
      store.put({
        id: `${uploadedAt}-${index}-${crypto.randomUUID()}`,
        name: file.name,
        subject,
        grade,
        tags,
        notes,
        size: file.size,
        type: file.type,
        kind: fileKind(file.type, file.name),
        uploadedAt,
        blob: file
      });
    });
  });

  uploadForm.reset();
  uploadForm.elements.subject.value = subject;
  uploadForm.elements.grade.value = grade || "Grade 4";
  selectedFilesLabel.textContent = "No files selected";
  libraryStatus.textContent = `${selectedFiles.length} file${selectedFiles.length === 1 ? "" : "s"} saved to the library.`;
  await readAllFiles();
}

async function downloadFile(id) {
  const file = libraryFiles.find((item) => item.id === id);
  if (!file) return;

  const url = URL.createObjectURL(file.blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = file.name;
  document.body.append(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

async function deleteFile(id) {
  const file = libraryFiles.find((item) => item.id === id);
  if (!file) return;

  const confirmed = window.confirm(`Delete "${file.name}" from this browser library?`);
  if (!confirmed) return;

  await runStore("readwrite", (store) => store.delete(id));
  libraryStatus.textContent = `"${file.name}" was removed from the library.`;
  await readAllFiles();
}

fileList.addEventListener("click", async (event) => {
  const button = event.target.closest("button[data-action]");
  if (!button) return;

  const { action, id } = button.dataset;
  if (action === "download") await downloadFile(id);
  if (action === "delete") await deleteFile(id);
});

uploadForm.addEventListener("submit", saveUploads);
fileInput.addEventListener("change", () => {
  const count = fileInput.files.length;
  selectedFilesLabel.textContent = count === 0
    ? "No files selected"
    : `${count} file${count === 1 ? "" : "s"} selected`;
});
searchInput.addEventListener("input", renderLibrary);
subjectFilter.addEventListener("change", renderLibrary);

readAllFiles().catch((error) => {
  libraryStatus.textContent = "This browser could not open the curriculum library.";
  console.error(error);
});
