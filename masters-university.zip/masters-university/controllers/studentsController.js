// controllers/studentsController.js

const { readData, generateStudentId, findStudentById, upsertStudent } = require('../utils/db');

/**
 * GET /api/students
 * Return all students (admin use)
 */
function getAllStudents(req, res) {
  try {
    const { students } = readData('students');
    res.json({ success: true, count: students.length, students });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
}

/**
 * POST /api/students
 * Enroll a new student
 * Body: { name, email, programId }
 */
function enrollStudent(req, res) {
  const { name, email, programId } = req.body;

  if (!name || !email || !programId) {
    return res.status(400).json({
      success: false,
      error: 'name, email, and programId are required.',
    });
  }

  // Validate program exists
  const { programs } = readData('programs');
  const program = programs.find(p => p.id === programId);
  if (!program) {
    return res.status(404).json({
      success: false,
      error: `Program "${programId}" not found.`,
    });
  }

  // Check duplicate email
  const { students } = readData('students');
  const existing = students.find(s => s.email === email);
  if (existing) {
    return res.status(409).json({
      success: false,
      error: 'A student with this email is already enrolled.',
      student: existing,
    });
  }

  const newStudent = {
    id: generateStudentId(),
    name: name.trim(),
    email: email.trim().toLowerCase(),
    programId,
    status: 'active',
    enrolledAt: new Date().toISOString(),
    lastActivity: new Date().toISOString(),
    completedModules: [],
    credentialId: null,
    degreeConferredAt: null,
  };

  const saved = upsertStudent(newStudent);

  res.status(201).json({
    success: true,
    message: `Welcome to The Master's University, ${name}. Your journey begins.`,
    student: saved,
    program: {
      id: program.id,
      title: program.title,
      code: program.code,
      totalModules: program.modules.length,
    },
  });
}

/**
 * GET /api/students/:id
 * Get a single student record
 */
function getStudent(req, res) {
  const { id } = req.params;
  const student = findStudentById(id);

  if (!student) {
    return res.status(404).json({ success: false, error: `Student "${id}" not found.` });
  }

  const { programs } = readData('programs');
  const program = programs.find(p => p.id === student.programId);
  const completedCount = (student.completedModules || []).length;
  const totalModules = program ? program.modules.length : 0;

  res.json({
    success: true,
    student,
    progress: {
      completed: completedCount,
      total: totalModules,
      percentComplete: totalModules > 0 ? Math.round((completedCount / totalModules) * 100) : 0,
    },
  });
}

module.exports = { getAllStudents, enrollStudent, getStudent };
