// utils/advisor.js — AI Advisor Engine
// Handles reflection evaluation, progress tracking, and degree conferral

const { readData, generateCredentialId, findStudentById, upsertStudent, saveCredential } = require('./db');

const BASE_URL = process.env.BASE_URL || 'http://localhost:3000';

// ─────────────────────────────────────────────
// EVALUATION ENGINE
// Assesses reflection depth on a 0–10 scale
// ─────────────────────────────────────────────

/**
 * Evaluate the depth of a student reflection
 * @param {string} text - student's reflection text
 * @param {object} module - module config (minimumWords, requiredDepthScore)
 * @returns {{ score: number, passed: boolean, feedback: string, wordCount: number }}
 */
function evaluateReflection(text, module) {
  const words = text.trim().split(/\s+/).filter(Boolean);
  const wordCount = words.length;
  let score = 0;
  const feedback = [];

  // 1. Word count check (0–2 pts)
  if (wordCount >= module.minimumWords) {
    score += 2;
  } else if (wordCount >= module.minimumWords * 0.75) {
    score += 1;
    feedback.push(`Your reflection is slightly short (${wordCount} words; aim for ${module.minimumWords}+).`);
  } else {
    feedback.push(`Your reflection needs more depth. You wrote ${wordCount} words; this module requires ${module.minimumWords}+ for mastery consideration.`);
  }

  // 2. Personal voice — use of first-person introspective language (0–2 pts)
  const personalMarkers = ['I ', 'my ', 'me ', 'myself', 'I\'ve', 'I\'m', 'I realize', 'I understand', 'I notice', 'I believe', 'I commit'];
  const personalCount = personalMarkers.reduce((acc, m) => acc + (text.toLowerCase().split(m.toLowerCase()).length - 1), 0);
  if (personalCount >= 8) score += 2;
  else if (personalCount >= 4) score += 1;
  else feedback.push('Your reflection could be more personal. Engage directly with your own experience and perspective.');

  // 3. Specificity — concrete examples and details (0–2 pts)
  const specificityMarkers = ['for example', 'specifically', 'in particular', 'such as', 'when I', 'because', 'therefore', 'as a result', 'this means', 'for instance'];
  const specificityCount = specificityMarkers.reduce((acc, m) => acc + (text.toLowerCase().split(m).length - 1), 0);
  if (specificityCount >= 4) score += 2;
  else if (specificityCount >= 2) score += 1;
  else feedback.push('Ground your reflection in specific examples, moments, or evidence from your actual experience.');

  // 4. Depth markers — evidence of genuine wrestling with ideas (0–2 pts)
  const depthMarkers = ['tension', 'paradox', 'struggle', 'realized', 'question', 'challenge', 'uncertain', 'discover', 'surprised', 'changed', 'transformed', 'deeper', 'beneath', 'underneath', 'actually', 'truth is', 'honest'];
  const depthCount = depthMarkers.reduce((acc, m) => acc + (text.toLowerCase().split(m).length - 1), 0);
  if (depthCount >= 4) score += 2;
  else if (depthCount >= 2) score += 1;
  else feedback.push('Go deeper. What genuinely surprised you? What are you still uncertain about? What changed in you?');

  // 5. Integration — connecting ideas across domains (0–2 pts)
  const integrationMarkers = ['this connects', 'relates to', 'in light of', 'builds on', 'this means that', 'therefore', 'as a result', 'which means', 'this affects', 'in practice', 'going forward', 'from now on', 'I will'];
  const integrationCount = integrationMarkers.reduce((acc, m) => acc + (text.toLowerCase().split(m).length - 1), 0);
  if (integrationCount >= 3) score += 2;
  else if (integrationCount >= 1) score += 1;
  else feedback.push('Connect your insight to action or to other ideas. What does this mean for how you will live and work?');

  const passed = score >= module.requiredDepthScore && wordCount >= module.minimumWords;

  return {
    score,
    maxScore: 10,
    passed,
    wordCount,
    feedback: feedback.length > 0 ? feedback : ['Excellent reflection — deep, specific, personal, and connected to action.'],
  };
}

// ─────────────────────────────────────────────
// PROGRESS ENGINE
// Tracks module completion and advancement
// ─────────────────────────────────────────────

/**
 * Get the current module for a student
 */
function getCurrentModule(student, programs) {
  const program = programs.find(p => p.id === student.programId);
  if (!program) return null;
  const completedIds = (student.completedModules || []).map(c => c.moduleId);
  return program.modules.find(m => !completedIds.includes(m.id)) || null;
}

/**
 * Mark a module as complete for a student
 */
function completeModule(student, moduleId, reflectionText, evaluationResult) {
  const completion = {
    moduleId,
    completedAt: new Date().toISOString(),
    reflectionText,
    evaluationScore: evaluationResult.score,
    wordCount: evaluationResult.wordCount,
  };

  const updatedStudent = {
    ...student,
    completedModules: [...(student.completedModules || []), completion],
    lastActivity: new Date().toISOString(),
  };

  return upsertStudent(updatedStudent);
}

/**
 * Check if a student has completed all modules
 */
function checkDegreeEligibility(student, programs) {
  const program = programs.find(p => p.id === student.programId);
  if (!program) return false;
  const completedIds = (student.completedModules || []).map(c => c.moduleId);
  return program.modules.every(m => completedIds.includes(m.id));
}

// ─────────────────────────────────────────────
// DEGREE ENGINE
// Issues credentials upon completion
// ─────────────────────────────────────────────

/**
 * Confer a degree credential
 */
function conferDegree(student, program) {
  const credentialId = generateCredentialId('FIS001');
  const issuedDate = new Date().toISOString().slice(0, 10);
  const verificationUrl = `${BASE_URL}/verify/${credentialId}`;

  const credential = {
    id: credentialId,
    studentId: student.id,
    studentName: student.name,
    programId: program.id,
    programTitle: program.title,
    programCode: program.code,
    issuedDate,
    verificationUrl,
    status: 'valid',
    issuedBy: "The Master's University of Professional Studies",
    seal: 'Veritas et Sapientia',
  };

  saveCredential(credential);

  // Update student record
  const updatedStudent = {
    ...student,
    credentialId,
    degreeConferredAt: new Date().toISOString(),
    status: 'graduated',
  };
  upsertStudent(updatedStudent);

  return credential;
}

// ─────────────────────────────────────────────
// ADVISOR MESSAGE HANDLER
// Routes student intents to appropriate responses
// ─────────────────────────────────────────────

/**
 * Process an incoming student message
 * @param {string} studentId
 * @param {string} intent - 'start' | 'next_module' | 'submit_reflection' | 'status' | 'help'
 * @param {string} [messageText] - the actual message content
 * @returns {{ reply: string, data: object }}
 */
async function processMessage(studentId, intent, messageText) {
  const student = findStudentById(studentId);
  if (!student) {
    return { reply: 'Student record not found. Please re-enroll or contact the Registrar.', data: {} };
  }

  const { programs } = readData('programs');
  const program = programs.find(p => p.id === student.programId);

  // ── START ──
  if (intent === 'start') {
    const currentModule = getCurrentModule(student, programs);
    if (!currentModule) {
      return {
        reply: `Welcome back, ${student.name}. You have completed all modules in ${program.title}. Type "status" to view your progress.`,
        data: { student, program },
      };
    }
    const reply = buildModuleIntroduction(student, currentModule, program);
    return { reply, data: { student, currentModule, program } };
  }

  // ── NEXT MODULE ──
  if (intent === 'next_module') {
    const currentModule = getCurrentModule(student, programs);
    if (!currentModule) {
      const eligible = checkDegreeEligibility(student, programs);
      if (eligible && !student.credentialId) {
        const credential = conferDegree(student, program);
        const reply = buildDegreeConferralMessage(student, credential, program);
        return { reply, data: { credential, student, program }, action: 'degree_conferred' };
      }
      return {
        reply: `You have completed all modules. ${student.credentialId ? `Your credential ID is: ${student.credentialId}` : 'Processing your credential...'}`,
        data: { student },
      };
    }
    const reply = buildModuleIntroduction(student, currentModule, program);
    return { reply, data: { student, currentModule, program } };
  }

  // ── SUBMIT REFLECTION ──
  if (intent === 'submit_reflection') {
    const currentModule = getCurrentModule(student, programs);
    if (!currentModule) {
      return {
        reply: "You have no active module awaiting a reflection. Type 'status' to see your progress.",
        data: {},
      };
    }

    const evaluation = evaluateReflection(messageText, currentModule);

    if (evaluation.passed) {
      const updatedStudent = completeModule(student, currentModule.id, messageText, evaluation);
      const nextModule = getCurrentModule(updatedStudent, programs);
      const eligible = checkDegreeEligibility(updatedStudent, programs);

      if (eligible && !updatedStudent.credentialId) {
        const credential = conferDegree(updatedStudent, program);
        const reply = buildDegreeConferralMessage(updatedStudent, credential, program);
        return { reply, data: { credential, student: updatedStudent, program }, action: 'degree_conferred' };
      }

      const reply = buildCompletionMessage(currentModule, evaluation, nextModule);
      return { reply, data: { evaluation, currentModule, nextModule }, action: 'module_complete' };
    } else {
      const reply = buildFeedbackMessage(currentModule, evaluation);
      return { reply, data: { evaluation }, action: 'resubmit_needed' };
    }
  }

  // ── STATUS ──
  if (intent === 'status') {
    const completedModules = student.completedModules || [];
    const totalModules = program.modules.length;
    const completedCount = completedModules.length;
    const currentModule = getCurrentModule(student, programs);

    let reply = `**Your Progress in ${program.title}**\n\n`;
    reply += `Modules completed: ${completedCount} of ${totalModules}\n\n`;

    program.modules.forEach((mod, i) => {
      const isDone = completedModules.find(c => c.moduleId === mod.id);
      const isCurrent = currentModule && currentModule.id === mod.id;
      const status = isDone ? '✓ Complete' : isCurrent ? '▶ In Progress' : '○ Upcoming';
      reply += `${i + 1}. ${mod.title} — ${status}\n`;
    });

    if (student.credentialId) {
      reply += `\n🎓 **Degree Conferred** | Credential ID: ${student.credentialId}`;
    } else if (completedCount > 0 && !currentModule) {
      reply += `\n🎓 All modules complete — credential being processed.`;
    }

    return { reply, data: { student, program, completedCount, totalModules } };
  }

  // ── HELP ──
  if (intent === 'help') {
    return {
      reply: `**Your AI Advisor is here.** Here's what you can do:\n\n` +
        `- **start** — Begin or resume your current module\n` +
        `- **next module** — Advance to the next module\n` +
        `- **status** — View your progress across all modules\n` +
        `- *Submit your reflection* — Paste your reflection text and I will evaluate it\n\n` +
        `You are studying: **${program.title}**\n` +
        `Your student ID: **${student.id}**`,
      data: {},
    };
  }

  // ── DEFAULT: treat as reflection submission ──
  if (messageText && messageText.split(' ').length > 30) {
    return processMessage(studentId, 'submit_reflection', messageText);
  }

  return {
    reply: `I didn't recognize that command, ${student.name}. Type **help** to see your options, or paste your reflection to submit it for evaluation.`,
    data: {},
  };
}

// ─────────────────────────────────────────────
// MESSAGE BUILDERS
// ─────────────────────────────────────────────

function buildModuleIntroduction(student, module, program) {
  const completedCount = (student.completedModules || []).length;
  return (
    `**MODULE ${module.sequence}: ${module.title.toUpperCase()}**\n` +
    `*${program.title} — Module ${module.sequence} of ${program.modules.length}*\n\n` +
    `${module.description}\n\n` +
    `**Learning Outcomes**\n` +
    module.learningOutcomes.map(o => `• ${o}`).join('\n') + '\n\n' +
    `**Your Mastery Task**\n` +
    `${module.masteryPrompt}\n\n` +
    `*Minimum: ${module.minimumWords} words. When ready, paste your reflection below.*`
  );
}

function buildCompletionMessage(completedModule, evaluation, nextModule) {
  let reply = `✓ **Module ${completedModule.sequence} Complete: ${completedModule.title}**\n\n`;
  reply += `Reflection score: **${evaluation.score}/10**\n`;
  reply += `Word count: ${evaluation.wordCount}\n\n`;

  if (evaluation.feedback[0].startsWith('Excellent')) {
    reply += `${evaluation.feedback[0]}\n\n`;
  }

  if (nextModule) {
    reply += `**Up Next: Module ${nextModule.sequence} — ${nextModule.title}**\n`;
    reply += `*Type "next module" to begin.*`;
  } else {
    reply += `**All modules completed.** Your degree is being conferred. Stand by.`;
  }

  return reply;
}

function buildFeedbackMessage(module, evaluation) {
  let reply = `**Reflection received — not yet at mastery level.**\n\n`;
  reply += `Score: ${evaluation.score}/10 (required: ${module.requiredDepthScore}/10)\n`;
  reply += `Word count: ${evaluation.wordCount} (required: ${module.minimumWords}+)\n\n`;
  reply += `**What to develop:**\n`;
  evaluation.feedback.forEach(f => { reply += `• ${f}\n`; });
  reply += `\n*Revise your reflection and resubmit. There is no penalty for resubmission — only the opportunity to go deeper.*`;
  return reply;
}

function buildDegreeConferralMessage(student, credential, program) {
  return (
    `\n🎓 **DEGREE CONFERRED**\n\n` +
    `By the authority of the Academic Council of\n` +
    `**The Master's University of Professional Studies**\n\n` +
    `This certifies that\n\n` +
    `**${student.name}**\n\n` +
    `has demonstrated mastery in all required modules of\n\n` +
    `**${program.title}**\n\n` +
    `and is hereby awarded the Graduate Certificate in Foundations of Identity & Systems.\n\n` +
    `*Veritas et Sapientia*\n\n` +
    `───────────────────────────\n` +
    `**Credential ID:** ${credential.id}\n` +
    `**Issued:** ${credential.issuedDate}\n` +
    `**Verify at:** ${credential.verificationUrl}\n` +
    `───────────────────────────\n\n` +
    `Congratulations, ${student.name}. This credential is yours. It cannot be taken from you.`
  );
}

module.exports = {
  processMessage,
  evaluateReflection,
  getCurrentModule,
  checkDegreeEligibility,
  conferDegree,
};
